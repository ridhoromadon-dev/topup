<?php include '../config/db.php';
$res=$conn->query("SELECT * FROM matches");
while($m=$res->fetch_assoc()){
 echo "<div>{$m['teamA']} vs {$m['teamB']}</div>";
}
