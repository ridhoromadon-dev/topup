<?php
echo json_encode([
 "redirect_url"=>"https://app.midtrans.com/snap/v2/vtweb/demo"
]);
