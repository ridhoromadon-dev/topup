<?php include '../config/db.php';

if(isset($_GET['delete'])){
 $conn->query("DELETE FROM users WHERE id=".$_GET['delete']);
}

$res=$conn->query("SELECT * FROM users");
while($u=$res->fetch_assoc()){
 echo $u['team_name']." <a href='?delete=".$u['id']."'>Delete</a><br>";
}
