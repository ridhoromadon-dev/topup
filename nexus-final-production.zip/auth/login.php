<?php include '../config/db.php';
if($_POST){
 $q=$conn->query("SELECT * FROM users WHERE team_name='$_POST[team]'");
 $u=$q->fetch_assoc();
 if($u && password_verify($_POST['password'],$u['password'])){
  $_SESSION['user']=$u;
  header("Location: ../dashboard.php");
 }
}
?>
<form method="POST">
<input name="team"><input name="password">
<button>Login</button>
</form>