<?php include '../config/db.php';
if($_POST){
 $pass=password_hash($_POST['password'],PASSWORD_DEFAULT);
 $conn->query("INSERT INTO users(team_name,password) VALUES('$_POST[team]','$pass')");
}
?>
<form method="POST">
<input name="team"><input name="password">
<button>Register</button>
</form>