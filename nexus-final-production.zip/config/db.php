<?php
$conn = new mysqli("localhost","root","","nexus");
if($conn->connect_error){ die("DB Error"); }
session_start();
?>