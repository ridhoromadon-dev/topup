<?php include 'config/db.php';
$res=$conn->query("SELECT * FROM matches");
?>
<h2>Bracket</h2>
<?php while($m=$res->fetch_assoc()){ ?>
<div><?= $m['teamA'] ?> vs <?= $m['teamB'] ?></div>
<?php } ?>
