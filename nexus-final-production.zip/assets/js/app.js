function pay(){
 fetch('api/payment.php',{method:'POST'})
 .then(r=>r.json())
 .then(d=>window.location=d.redirect_url);
}

// polling bracket update
setInterval(()=>{
 fetch('api/matches.php')
 .then(r=>r.text())
 .then(html=>document.getElementById("bracket").innerHTML=html);
},3000);
