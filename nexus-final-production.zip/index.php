<?php include 'config/db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white text-center p-10">
<h1 class="text-4xl font-bold text-cyan-400">NEXUS TOURNAMENT</h1>

<a href="auth/login.php" class="block mt-4">Login</a>
<a href="auth/register.php" class="block">Register</a>

<button onclick="pay()" class="mt-6 bg-cyan-400 text-black px-4 py-2 rounded">Pay</button>

<script src="assets/js/app.js"></script>
</body>
</html>
